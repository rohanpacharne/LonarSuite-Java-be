package com.lonar.lexa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LexaApplicationTests {

	@Test
	void contextLoads() {
	}

}
